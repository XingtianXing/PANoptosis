circos.initializeWithIdeogram(plotType = c("labels", "axis"))
circos.track(ylim = c(0, 1))
circos.genomicIdeogram() # put ideogram as the third track
circos.genomicIdeogram(track.height = 0.2)
circos.clear()

circos.initializeWithIdeogram()
bed <- generateRandomBed(nr = 100, nc = 4)
col_fun <- colorRamp2(
  c(-1, 0, 1), 
  c("#ef8a62", "#f7f7f7", "#67a9cf")
)
circos.genomicHeatmap(
  bed, col = col_fun, side = "inside", 
  border = "white"
)
circos.clear()

circos.initializeWithIdeogram()
bed <- generateRandomBed(
  nr = 50, fun = function(k) sample(letters, k, replace = TRUE)
)
bed[1, 4] <- "aaaaa"


bed <- read.csv(file = 'PRGs_gene.pos.csv',header = T)
circos.genomicLabels(
  bed, labels.column = 4, side = "inside", 
  col = "#ef8a62"
)
circos.clear()


circos.initializeWithIdeogram(species = "hg38")

