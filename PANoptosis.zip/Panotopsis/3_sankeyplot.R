install.packages('ggalluvial')
library(ggalluvial)

data(vaccinations)

head(vaccinations)
#      survey freq subject response start_date   end_date
# 1 ms153_NSA   48       1   Always 2010-09-22 2010-10-25
# 2 ms153_NSA    9       2   Always 2010-09-22 2010-10-25
# 3 ms153_NSA   66       3   Always 2010-09-22 2010-10-25
# 4 ms153_NSA    1       4   Always 2010-09-22 2010-10-25
# 5 ms153_NSA   11       5   Always 2010-09-22 2010-10-25
# 6 ms153_NSA    1       6   Always 2010-09-22 2010-10-25

ggplot(data = riskScore_cli,
       aes(axis1 = Cluster,   # First variable on the X-axis
           axis2 = riskScore2, # Second variable on the X-axis
           axis3 = State,   # Third variable on the X-axis
           y = value)) +
  geom_alluvium(aes(fill = Cluster)) +
  geom_stratum(width = 0.5) +
  geom_text(stat = "stratum",
            aes(label = after_stat(stratum))) +
  theme_void()+
  scale_fill_manual(values = cluster.col)
ggsave('4_sankey diagram_median.pdf',width = 6,height = 4,dpi = 800)
