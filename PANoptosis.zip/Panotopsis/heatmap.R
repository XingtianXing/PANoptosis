clinical_matrix_Tumor <- read.csv('clinical_matrix_tumor.csv')
names(clinical_matrix_Tumor)
clu1 <- read.csv('cluster.csv')
names(clu1)[1] <- 'entity_submitter_id'
clinical_matrix_Tumor <- merge(clinical_matrix_Tumor,clu1,by = 'entity_submitter_id')
names(clinical_matrix_Tumor)[160] <- 'cluster'

tumor_matrix_PRGs <- read.csv('tumor_matrix_fpkm.csv',row.names = 1,sep = ',',
                              check.names = F)
tumor_matrix_PRGs <- tumor_matrix_PRGs[rownames(tumor_matrix_PRGs)%in%PRG$gene,]
#vec <- colnames(tumor_matrix_PRGs)

colnames(clinical_matrix_Tumor)
pick.clinical <- c('entity_submitter_id','age','gender','vital_status',
                   'ajcc_pathologic_stage',
                   'prior_malignancy',
                   'treatment_or_therapy','cluster')
names(clinical_matrix_Tumor)[2] <- 'age'
clinical_matrix_Tumor <- clinical_matrix_Tumor[,colnames(clinical_matrix_Tumor)%in%pick.clinical ]
#vec <- as.vector(vec)

#clinical_matrix_Tumor <- clinical_matrix_Tumor %>%
#  arrange_at(2:13) %>%
#  arrange(match(entity_submitter_id,vec))

clinical_matrix_Tumor_1 <- annotation_col[order(annotation_col$cluster),]
vec <- rownames(clinical_matrix_Tumor_1)
vec <- as.vector(vec)

tumor_matrix_PRGs <- t(tumor_matrix_PRGs)
tumor_matrix_PRGs <- as.data.frame(tumor_matrix_PRGs)
tumor_matrix_PRGs$sample <- rownames(tumor_matrix_PRGs)
tumor_matrix_PRGs <- tumor_matrix_PRGs %>%
  arrange_at(1:19) %>%
  arrange(match(sample,vec))
tumor_matrix_PRGs <- tumor_matrix_PRGs[,-20]
tumor_matrix_PRGs <- as.matrix(tumor_matrix_PRGs)
tumor_matrix_PRGs <- t(tumor_matrix_PRGs)


annotation_col <- as.data.frame(clinical_matrix_Tumor)
rownames(annotation_col) <- annotation_col[,1]
colnames(annotation_col)
annotation_col <- annotation_col[,c(3,4,7,9,11,13)]
names(clinical_matrix_Tumor)[7] <- 'treatment'
table(clinical_matrix_Tumor$age)
  
ann_colors <- list(#group=c('Tumor' = "#EFC000FF",'Normal' = '#0073C2FF'),
                   gender= c('male' = 'navy','female' = '#CD534CFF'),
                   cluster=c('1'='navy','2'='red'),
                   stage=c('Stage I' = '#7FC97F',
                           'Stage II' = '#BEAED4',
                           'Stage III' = '#FDC086',
                           'Stage IV' ='#F0027F',
                           'Stage IVA' = '#FFFF99',
                           'Stage IVB' = '#386CB0'),
                   status=c('Alive'='#FFB90F','Dead'='black'),
                   prior_malignancy=c('yes'='burlywood4','no'='darkcyan'),
                   treatment=c('no'='darkkhaki','yes'='darkmagenta','not reported'='darkgray'),
                   age=c('1'='deeppink3','0'='deepskyblue4')
                   ) #颜色设置


col = colorRampPalette(brewer.pal(11,'RdGy'))(100)
col = rev(col)
pheatmap(tumor_matrix_PRGs,cluster_rows = T,cluster_cols = F,
         #color=colorRampPalette(c("navy","white","firebrick3"))(100),
         color = col,
         show_colnames = F,border_color = NA,scale = "row",show_rownames =T,
         annotation_col = clinical_matrix_Tumor,
         name = 'Expression',
         cellwidth = 8,cellheight = 10,
         fontsize_row = 8,
         annotation_colors = ann_colors,
         legend_breaks = 2
)
