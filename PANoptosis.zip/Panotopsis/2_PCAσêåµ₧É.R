#######PCA分析，倒入fpkm文件，转置为行为样本，列为基因名的文件
tumor_matrix <- read.csv('tumor_matrix_fpkm.csv',row.names = 1,check.names = F)
tumor_matrix <- tumor_matrix[rowSums(tumor_matrix)>0,]
#tumor_matrix <- t(tumor_matrix)
#tumor_matrix <- tumor_matrix[,colSums(tumor_matrix)>0]
nrow(tumor_matrix)

####主成分分析可视化
#install.packages("ggthemes")
library(ggpubr)
library(ggthemes)
#BiocManager::install("gmodels")
library(gmodels)
library(export)

#用gmodels里面自带的fast.prcomp对PC进行计算。
##这里的矩阵行是基因名，列是样本名
fpkm <- expr_PRG
pca.info <- fast.prcomp(fpkm) ###矩阵只有数值没有字符,数据不用转置
#查看PCA的结果。
head(pca.info)
summary(pca.info) #能看到每个PC具体的解释比例
head(pca.info$rotation) #特征向量，回归系数
head(pca.info$sdev) #特征值的开方
head(pca.info$x) #样本得分score
vec <- colnames(fpkm)
clu1 <- clu1 %>%
  arrange_at(2) %>%
  arrange(match(entity_submitter_id,vec))
type <- clu3[match(rownames(pca.info$rotation),rownames(clu3)),]
type.info <- as.vector(type$cluster3)
type.info <- as.character(type.info)

pca.data <- data.frame(sample = rownames(pca.info$rotation), pca.info$rotation)
pca.data <- data.frame(sample = rownames(pca.info$rotation), 
                       Type=c(type.info), pca.info$rotation)
#绘图，不同的参数会有不同的结果。具体的参数以及含义自行百度。以下是两个例子。
ggscatter(pca.data,x="PC1", y="PC2", color="sample", ellipse=TRUE, 
          ellipse.type="convex",label.select = pca.data$sample,label = T)

ggscatter(pca.data,x="PC1", y="PC2", color="Type",ellipse=F, 
              #ellipse.type="convex",
              size=2, 
              ellipse.border.remove=TRUE,
              label.select = pca.data$sample,
              label = TRUE,
              repel=TRUE, main="PCA plot")+ 
  labs(title = "PCA",
       x = "PC_1", 
       y = "PC_2")+
  theme(axis.title.x = element_text(face = "bold",size = 20),
        axis.title.y = element_text(face = "bold",size = 20),
        legend.title = element_text(face = "bold",size = 16))+
  theme_par()+theme(aspect.ratio = 1)+
  scale_color_manual(values = cluster3.col)
ggsave(filename = '2_PCA_Cluster3_real.pdf',width = 6,height = 6,dpi = 800)
p

ggsave(filename = "5_PCA_Tumor_Halmarks.png",width = 9, height = 7.5)

