#install.packages("rjson")
library("rjson")
json <- jsonlite::fromJSON("metadata.cart.2023-07-28.json")
View(json)
#id <- json$associated_entities[[1]][,1]
sample_id <- sapply(json$associated_entities,function(x){x[,1]})
file_sample <- data.frame(sample_id,file_name=json$file_name)  

#count_file <- list.files('gdc_download_20220418_090958.803273',pattern = '*.tsv',recursive = TRUE)
count_file <- list.files('gdc_download_20230728_153815.519051',pattern = '*gene_counts.tsv',recursive = TRUE)
count_file_name <- strsplit(count_file,split='/')
count_file_name <- sapply(count_file_name,function(x){x[2]})

matrix = data.frame(matrix(nrow=60660,ncol=0))
for (i in 1:length(count_file_name)){
  path = paste0('gdc_download_20230728_153815.519051//',count_file[i])
  data<- read.delim(path,fill = TRUE,header = FALSE,row.names = 1)
  colnames(data)<-data[2,]
  data <-data[-c(1:6),]
  data <- data[3] #取出unstranded列（得到COUNT矩阵），若想提取fpkm-unstranded则改为data[7]，fpkm-up-unstranded改为data[8]
  colnames(data) <- file_sample$sample_id[which(file_sample$file_name==count_file_name[i])]
  matrix <- cbind(matrix,data)
}

write.csv(matrix,'TCGA_matrix.csv',row.names = TRUE)

#------------------------------增加部分：设置Gene Symbol为列名的矩阵（前面得到的是Ensembl ID）------------------------------------------
path = paste0('gdc_download_20230728_153815.519051//',count_file[1])
data<- as.matrix(read.delim(path,fill = TRUE,header = FALSE,row.names = 1))
gene_name <-data[-c(1:6),1]
matrix0 <- cbind(gene_name,matrix)
#将gene_name列去除重复的基因，保留每个基因最大表达量结果
matrix0 <- aggregate( . ~ gene_name,data=matrix0, max)    
#将gene_name列设为行名
rownames(matrix0) <- matrix0[,1]
matrix0 <- matrix0[,-1]
write.csv(matrix0,'TCGA_Gene Symbol_matrix.csv',row.names = TRUE)


#------------------------------增加部分：分为normal和tumor矩阵--------------------------
sample <- colnames(matrix0)

normal <- c()
tumor <- c()

for (i in 1:length(sample)){
  if((substring(colnames(matrix0)[i],14,15)>=10)){    #14、15位置大于等于10的为normal样本
    normal <- append(normal,sample[i])
  } else {
    tumor <- append(tumor,sample[i])
  }
}

tumor_matrix <- matrix0[,tumor]
normal_matrix <- matrix0[,normal]

#写入文件
write.csv(tumor_matrix,'tumor_matrix.csv',row.names = TRUE)
write.csv(normal_matrix,'normal_matrix.csv',row.names = TRUE)


##########下载
json <- jsonlite::fromJSON("metadata.cart.2023-07-28.json")
View(json)
entity_submitter_id <- sapply(json$associated_entities,function(x){x[,1]})
case_id <- sapply(json$associated_entities,function(x){x[,3]})
sample_case <- t(rbind(entity_submitter_id,case_id))

clinical <- read.delim('clinical.cart.2023-07-28/clinical.tsv',header = T)
clinical <- as.data.frame(clinical[duplicated(clinical$case_id),])

clinical_matrix <- merge(sample_case,clinical,by="case_id",all.x=T)
clinical_matrix <- clinical_matrix[,-1]

write.csv(clinical_matrix,'clinical_matrix.csv',row.names = TRUE)
