install.packages('Hmisc')
library(glmnet)
library(plyr)
library(caret)
library(corrplot)
library(Hmisc)

data1 <- new_exprSet2
data1 <- t(data1)
data1 <- as.data.frame(data1)
data1 <- data1[,colnames(data1)%in%resAvsB_diff3$SYMBOL]
data1$sample <- rownames(data1)

data1 <- data1[match(rownames(clu3),rownames(data1)),]
rownames(data1)[1:10]
rownames(clu3)[1:10]
data1$cluster <- clu3$cluster

sample <- c('CCA_RO_4', 'CCA_TH_130', 'CCA_RO_6')
KM.1 <- KM[-c(which(rownames(KM)%in%sample)),]
KM.1 <- KM.1[match(rownames(clu3),rownames(KM.1)),]
rownames(data)[1:10]
rownames(clu3)[1:10]
all(rownames(KM.1) == rownames(data1))

data1$state =KM.1$State
data1$OS = KM.1$OS
data1[,1:52] <- mutate_all(data[,1:52],as.numeric)


##LASSO+COX
x <- as.matrix(data[,1:400])
y <- Surv(data$OS,data$state)
fit <- glmnet(x,y,family='cox',alpha=1,nlambda = 100)
plot(fit,xvar='lambda')


x1 <- as.matrix(data1[,1:52])
y1 <- Surv(data1$OS,data1$state)
fit1 <- glmnet(x,y,family='cox',alpha=1,nlambda = 100)
print(fit1)
plot(fit1,xvar='lambda')

lasso_fit <- cv.glmnet(x,y,family='cox',nlambda = 100, alpha =1)
lasso_fit1 <- cv.glmnet(x1,y1,family='cox',nlambda = 100, alpha =1)
plot(lasso_fit)
plot(lasso_fit1)
print(lasso_fit)
print(lasso_fit1)

coefficient <- coef(lasso_fit,s='lambda.min')
coe <- coefficient@x
coe <- as.data.frame(coe)
Active_Index <- which(as.numeric(coefficient)!=0)
active_coeff <- as.numeric(coefficient)[Active_Index]
Variable <- rownames(coefficient)[Active_Index]
Variable <- as.data.frame(Variable)
Variable <- cbind(Variable,coe)
write.csv(Variable,file = '4_lasso_Result_0.5fc_min_coe.csv',row.names = T)

ExtractVar <- unique(Variable$Variable)
data3 <- data.frame(subset(data,select=c('OS','state',ExtractVar)))
write.csv(data3,file = '4_lasso_Result_0.5fc_min.csv',row.names = T)

multiCox <- coxph(Surv(OS,state) ~ ., data =  data3)
summary(multiCox)
#ph_multi <- cox.zph(multiCox)
#ph_table <- ph_multi$table[-nrow(ph_multi$table),]
formula_for_multivariate <- as.formula(paste0('Surv(OS,state)~',paste(rownames(ph_table)[ph_table[,3]>0.05],sep='',collapse='+')))
multiCox1 <- coxph(formula_for_multivariate, data =  data3)
ggforest(model = multiCox1,data = data3,cpositions = c(0.01,0.1,0.3),
         fontsize=0.7,
         noDigits=2)

p<- ggforest(multiCox,data3)
print(p)
HR <- exp(multiCox$coefficients)
HR
#predict函数计算风险评分
riskScore=predict(multiCox,type="risk",newdata=data3) 
riskScore<-as.data.frame(riskScore)

riskScore$sample <- rownames(riskScore)
head(riskScore,2) 

######riskScore 二分绘制KM##########
all(rownames(riskScore)==rownames(KM.1))
riskScore_cli <- KM.1
riskScore_cli$riskScore <- riskScore$riskScore
#按照中位数分为高低风险两组
riskScore_cli$riskScore2 <- ifelse(riskScore_cli$riskScore > median(riskScore_cli$riskScore),
                                   "High","Low")
riskScore_cli$riskScore3 <- ifelse(riskScore_cli$riskScore > 0.9200198,
                                   "High","Low")
#KM分析
fit <- survfit(Surv(OS, State) ~ riskScore2, data=riskScore_cli)

lasso_KM <- ggsurvplot(fit, data = riskScore_cli,
                       pval = T,
                       risk.table = T,
                       surv.median.line = "hv", #添加中位生存曲线
                       #palette=c("red", "blue"),  #更改线的颜色
                       #legend.labs=c("High risk","Low risk"), #标签
                       legend.title="RiskScore",
                       title="Overall survival", #标题
                       ylab="Cumulative survival (percentage)",xlab = " Time (Days)", #更改横纵坐标
                       censor.shape = 124,censor.size = 2,conf.int = FALSE, #删失点的形状和大小
                       break.x.by = 720#横坐标间隔
)
lasso_KM

lasso_KM <-ggsurvplot(fit,
           pval = TRUE, conf.int = TRUE,
           risk.table = TRUE, # 添加风险表
           risk.table.col = "strata", # 根据分层更改风险表颜色
           linetype = "strata", # 根据分层更改线型
           surv.median.line = "hv", # 同时显示垂直和水平参考线
           #ggtheme = theme(aspect.ratio = 0.6), # 更改ggplot2的主题
           palette = c(#"#EE7600", "#008B8B",
             'brown3','#00008B'))
lasso_KM

##画TimeROC图
BiocManager::install('timeROC')
library(timeROC)
with(riskScore_cli,
     ROC_riskscore <<- timeROC(T = OS,
                               delta = State,
                               marker = riskScore,
                               cause = 1,
                               weighting = "marginal",
                               times = c(365,1080,1800),
                               ROC = TRUE,
                               iid = TRUE)
)

plot(ROC_riskscore, time = 365, col = "red", add = F,title = "")
plot(ROC_riskscore, time = 1080, col = "blue", add = T)
plot(ROC_riskscore, time = 1800, col = "purple", add = T)
legend("bottomright",c("1-Year","3-Year","5-Year"),col=c("red","blue","purple"),lty=1,lwd=2)
text(0.5,0.2,paste("1-Year AUC = ",round(ROC_riskscore$AUC[1],3)))
text(0.5,0.15,paste("3-Year AUC = ",round(ROC_riskscore$AUC[2],3)))
text(0.5,0.1,paste("5-Year AUC = ",round(ROC_riskscore$AUC[3],3)))
##LASSO+LOGITIS
fit <- glmnet(x,y,family='binomial',alpha=1)
print(fit)
plot(fit,xvar='lambda')

lasso_fit <- cv.glmnet(x,y,family='binomial',alpha=1,type.measure = 'auc',nlambda=1500) #确保x是数值型向量
print(lasso_fit)
plot(lasso_fit,xvar='lambda')

phe_115 <- phe[-which(rownames(phe) %in% sample),]
phe_gai <- read.csv('clinical_115_gai.csv',header = T,row.names = 1,check.names = F)
phe_gai <- phe_gai[match(rownames(phe_115),rownames(phe_gai)),]
all(rownames(phe_115)==rownames(phe_gai))
colnames(phe_115)
phe_gai$PSC <- phe_115$`Primary Sclerosing cholangitis`
phe_gai$HCV <- phe_115$HCV
phe_gai$HBV <- phe_115$HBV
phe_gai$Histology <- phe_115$Histology
phe_gai$TNM <- phe_115$`TNM staging`
phe_gai$state <- phe_115$Stage

library(survival)
library(rms)
library(survminer)
ddist <- datadist(phe_gai)
options(datadist = 'ddist')
table(phe_gai$PSC)
phe_gai$HCV[is.na(phe_gai$HCV)] <- 'Unknown' 
phe_gai$Histology[phe_gai$Histology=='TBA'] <- NA
phe_gai$HBV[phe_gai$HBV=='Unknown'] <- NA
phe_gai$age <- as.character(phe_gai$age)
f <- cph(Surv(OS,State) ~ Sex+age+riskScore3+PSC,
         data = phe_gai,x=TRUE,y=TRUE,surv = TRUE)
print(f)
survival <- Survival(f)
survival1 <- function(x)survival(365,x) 
survival2 <- function(x)survival(1080,x)
survival3 <- function(x)survival(1800,x)
nom <- nomogram(f,fun= list(survival1,survival2,survival3),maxscale=100,
                fun.at = c(0.1,seq(0.1,0.9,by=0.1),1),
                funlabel = c('1-Year-Survival','3-Year-Survival','5-Year-Survival'))
plot(nom,xfrac = 0.35, #变量与图形的占比
     cex.var = 1.1, #变量字体加粗
     cex.axis = 0.8, #数轴：字体的大小
     tcl = -0.2, #数轴：刻度的长度
     lmgp = 0.3,#数轴：文字与刻度的距离
     label.every = 1, #数轴：刻度下文字 1-连续显示
     col.grid = gray(c(0.8,0.95))
     )

##评价COX回归的预测效果
##计算C-index
rcorrcens(Surv(OS,State) ~ predict(f), data =  phe_gai)

## 绘制校正曲线
## 重新调整模型函数f2，也即添加x=T, y=T
f2 <- psm(Surv(OS,State) ~ Sex+age+riskScore3+PSC, data =  phe_gai, x=T, y=T, dist='lognormal') 
## 构建校正曲线

cal1 <- calibrate(f2, 
                  cmethod='KM', 
                  method="boot", 
                  u=365, # u需要与之前模型中定义好的time.inc一致，即365或730；
                  m=30, #每次抽样的样本量，
                  B=1000) #抽样次数
plot(cal1)

cal3 <- calibrate(f2, 
                  cmethod='KM', 
                  method="boot", 
                  u=1080, # u需要与之前模型中定义好的time.inc一致，即365或730；
                  m=30, #每次抽样的样本量，
                  B=1000) #抽样次数

cal5 <- calibrate(f2, 
                  cmethod='KM', 
                  method="boot", 
                  u=1800, # u需要与之前模型中定义好的time.inc一致，即365或730；
                  m=30, #每次抽样的样本量，
                  B=1000) #抽样次数
## m要根据样本量来确定，由于标准曲线一般将所有样本分为3组（在图中显示3个点）
## 绘制校正曲线

dev.off()

plot(cal1,lwd=2,lty=1,
     conf.int=T,# 是否显示置信区间
     errbar.col="blue",#直线曲线bar颜色
     col="red", # 曲线颜色
     #xlim=c(0.25,0.6),ylim=c(0.15,0.70),
     xlab="Nomogram-Predicted Probability of 1-Year DFS",
     ylab="Actual 1-Year DFS (proportion)",
     subtitles = F)#不显示副标题

plot(cal5,
     lwd = 2,#error bar的粗细
     lty = 1,#error bar的类型，可以是0-6
     errbar.col = c("purple"),#error bar的颜色
     #xlim = c(0,1),
     ylim= c(0,1),
     xlab = "Nomogram-prediced OS (%)",ylab = "Observed OS (%)",
     cex.lab=1.2, cex.axis=1, cex.main=1.2, cex.sub=0.6) #字的大小
lines(cal5[,c('mean.predicted',"KM")], 
      type = 'b', #连线的类型，可以是"p","b","o"
      lwd = 2, #连线的粗细
      pch = 16, #点的形状，可以是0-20
      col = c("purple")) #连线的颜色
mtext("")
box(lwd = 1) #边框粗细
abline(0,1,lty = 3, #对角线为虚线
       lwd = 2, #对角线的粗细
       col = c("#224444")#对角线的颜色
) 

legend("topleft", #图例的位置
       legend = c("5-year"), #图例文字
       col =c("purple"), #图例线的颜色，与文字对应
       lwd = 2,#图例中线的粗细
       cex = 1.2,#图例字体大小
       bty = "n")#不显示图例边框

##展示2条
plot(cal3,lwd = 2,lty = 1,errbar.col = c("#2166AC"),
     bty = "l", #只画左边和下边框
     #xlim = c(0,1),ylim= c(0,1),
     xlab = "Nomogram-prediced OS (%)",ylab = "Observed OS (%)",
     col = c("#2166AC"),
     cex.lab=1.2,cex.axis=1, cex.main=1.2, cex.sub=0.6)
lines(cal3[,c('mean.predicted',"KM")],
      type = 'b', lwd = 1, col = c("#2166AC"), pch = 16)
mtext("")

plot(cal5,lwd = 2,lty = 1,errbar.col = c("#B2182B"),
     #xlim = c(0,1),ylim= c(0,1),col = c("#B2182B"),
     add = T)
lines(cal5[,c('mean.predicted',"KM")],
      type = 'b', lwd = 1, col = c("#B2182B"), pch = 16)

abline(0,1, lwd = 2, lty = 3, col = c("#224444"))

legend("topleft", #图例的位置
       legend = c("1-year","3-year"), #图例文字
       col =c("#2166AC","#B2182B"), #图例线的颜色，与文字对应
       lwd = 2,#图例中线的粗细
       cex = 1.2,#图例字体大小
       bty = "n")#不显示图例边框
dev.off()

#install.packages("nomogramEx")
#install.packages('regplot')
library(regplot)
library(nomogramEx)

nomogramEx(nomo=nom,np=2,digit = 12)

mycol <- brewer.pal(8,'Accent')
regplot(f2)
regplot(f2,failtime = c(365,1080,1800),
        plots=c("boxplot","boxes"), observation=phe_gai[1,],
        obscol = "#326db1",
        title="Prognosis Prediction Nomogram", 
        clickable=TRUE, points=TRUE,droplines=TRUE)

f2 <- cph(Surv(OS,State) ~ Sex+age+riskScore3+PSC,
         data = phe_gai,x=T,y=T)

library(regplot)
library(survival)
f2 <- coxph(formula =  as.formula(Surv(OS,State) ~ Sex+age+PSC), 
data = phe_gai)
which(rownames(phe_gai)== 'CCA_TH_23') 
regplot(f2,
        observation=phe_gai[87,], #用哪行观测
        obscol = "#326db1",
        failtime = c(365,1080,1800), 
        plots = c("boxplot","boxes"),
        droplines = T, # 是否画竖线
        points = T,
        title = "Prognosis Prediction Nomogram", # 更换标题
        # odds = T, # 是否显示OR值
        showP = T, # 是否显示变量的显著性标记（默认：T）
        rank = "sd", # 根据sd给变量排序
        # interval="confidence", # 展示可信区间
        clickable = F, # 是否可以交互（默认：F）
        prfail = T)
rownames(phe_gai)[87]
