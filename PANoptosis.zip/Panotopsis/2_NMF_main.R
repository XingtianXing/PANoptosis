if (!requireNamespace("ConsensusClusterPlus", quietly = TRUE)) {
  BiocManager::install("ConsensusClusterPlus")
}

library(ConsensusClusterPlus)

rm(PRGs)
tumor_matrix <- read.csv('TCGA/tumor_matrix.csv')
tumor_matrix_PRGs <- tumor_matrix[tumor_matrix$X %in% PRG$gene,]
rownames(tumor_matrix_PRGs) <- tumor_matrix_PRGs$X
tumor_matrix_PRGs <- tumor_matrix_PRGs[,-1]
dim(tumor_matrix_PRGs)
class(tumor_matrix_PRGs)
tumor_matrix_PRGs <- as.matrix(tumor_matrix_PRGs)

tumor_matrix_PRGs = sweep(tumor_matrix_PRGs,1, apply(tumor_matrix_PRGs,1,median,na.rm=T))

title <- '~/Desktop/Panoptosis/'
results <- ConsensusClusterPlus(tumor_matrix_PRGs,maxK = 6,
                                reps = 50,pItem = 0.8,
                                pFeature = 0.8,clusterAlg = 'hc',
                                distance = 'pearson',title = title,
                              plot = 'pdf')

consensusTree <- results[[2]][["consensusTree"]]
consensusTree

consensusMatrix <- results[[3]][["consensusMatrix"]]
consensusMatrix[1:5, 1:5]
##      [,1] [,2] [,3] [,4] [,5]
## [1,]    1    1    1    1    1
## [2,]    1    1    1    1    1
## [3,]    1    1    1    1    1
## [4,]    1    1    1    1    1
## [5,]    1    1    1    1    1
# 样本分类
consensusClass <- results[[3]][["consensusClass"]]

icl = calcICL(results,title=title,plot="pdf")
icl[["clusterConsensus"]]

dim(icl[["itemConsensus"]])

icl[["itemConsensus"]][1:5,]
cluster <- icl[["itemConsensus"]]
cluster <- cluster[cluster$k ==2,]

Matrix_PRG_fpkm <- read.csv('All_PRGs_fpkm.csv',row.names = 1) #h行为样本，列为基因
Matrix_PRG_fpkm <- log(Matrix_PRG_fpkm+1)
gene_cor <- cor(Matrix_PRG_fpkm,method = 'pearson')
diag(gene_cor) <- 0
gene_cor <- reshape2::melt(gene_cor)
gene_cor <- subset(gene_cor,value !=0)
head(gene_cor)
library(circlize)
chordDiagram(gene_cor,
             annotationTrack =c('grid','name','axis'),
             col=colorRamp2(c(-1,0,1),c('navy','white','red'),transparency = 0.5),
             annotationTrackHeight = c(0.05,0.05)
             )

grid.col <- c() #自定义基因的颜色


