rm(list=ls())
options(stringsAsFactors = F)
getwd()

data<-read.table("MvsC.Introns.counts1.csv",header = T,sep = ",")##以第二列作为行名，可以更改

#####################################   mRNA差异表达分析####################################################

# BiocManager::install('DESeq')
# install.packages(dplyr)
library(DESeq2)
library(dplyr)

###制作countData
clu3 <- read.csv('GSE89749/cluster.orig.csv',header = T,row.names = 1)
sample <- c('CCA_RO_4', 'CCA_TH_130', 'CCA_RO_6')
clu3 <- clu3[-c(which(rownames(clu3)%in%sample)),]

new_exprSet2 <- new_exprSet[,-c(which(colnames(new_exprSet)%in%sample))]
new_exprSet2 <- t(new_exprSet2)
new_exprSet2 <- new_exprSet2[match(rownames(clu3),rownames(new_exprSet2)),]
new_exprSet2 <- t(new_exprSet2)
new_exprSet2 <- round(new_exprSet2)
new_exprSet2 <- as.data.frame(new_exprSet2)
colnames(new_exprSet2)[1:10]
rownames(clu3)[1:10]

table(clu3$cluster)
group<-c(rep("A",80),rep("B",35))

metadata<-data.frame(group) ###将control和Model
rownames(metadata) <- colnames(new_exprSet2)

new_exprSet <- new_exprSet[rowSums(new_exprSet) > 0,] ##去除表达量都为0的
new_exprSet <- na.omit(new_exprSet) ##去除缺失值
gene_name <- as.data.frame(rownames(new_exprSet2))
names(gene_name) <- 'gene_name'
new_exprSet2<-cbind(gene_name,new_exprSet2)
new_exprSet2<- new_exprSet2[!duplicated(new_exprSet2$gene_name), ]
new_exprSet2[,1] <- as.factor(new_exprSet2$gene_name)

all(rownames(metadata) %in% colnames(new_exprSet2))
all(rownames(metadata) == colnames(new_exprSet2)[2:116])

###构建 DESeq对象
mRNA_dds <-DESeqDataSetFromMatrix(countData=new_exprSet2, 
                                  colData=metadata, 
                                  design=~group,
                                  tidy = T)
##count必须是整数，第一行为基因名

mRNA2_dds <- DESeq(mRNA_dds) 

#####################contrast后面三个参数，先是列名，再是分子和分母

resAvsB <- results(mRNA2_dds , contrast = c("group","A","B"),tidy=TRUE)

resBvsA <- results(mRNA2_dds , contrast = c("group","B","A"),tidy=TRUE)

summary(resAvsB)

# 按照logFC进行排序
resAvsB_order <- resAvsB[order(-resAvsB$log2FoldChange),] 

resAvsB_diff <- resAvsB_all%>% filter(pvalue <0.05&abs(log2FoldChange)>0.5)

rownames(resAvsB_diff)<-resAvsB_diff$row

names(resAvsB_diff)[1]<-"SYMBOL"

#BiocManager::install('clusterProfiler')

library(clusterProfiler)

####做富集前先进行ID转化
#BiocManager::install("org.Mm.eg.db")##小鼠的参考基因组 org.Hs.eg.db人的

eg = bitr(resAvsB_diff$SYMBOL, fromType="SYMBOL", toType="ENTREZID", OrgDb='org.Hs.eg.db')

resAvsB_diff2<-inner_join(eg,resAvsB_diff,by="SYMBOL") ###取共有的集合做内连接

all = bitr(resAvsB_order$row, fromType="SYMBOL", toType="ENTREZID", OrgDb="org.Hs.eg.db")

names(resAvsB_order)[1] <- "SYMBOL"

resAvsB_all<-inner_join(all,resAvsB_order,by="SYMBOL")

geneorder <- resAvsB_all$log2FoldChange

names(geneorder) <- resAvsB_all$ENTREZID

write.csv(resAvsB_all, file = 'DEseq_All_AvsB_115.csv', quote = F, row.names = F)
write.csv(resAvsB_diff2, file = 'DEseq_deg_AvsB_115.csv', quote = F, row.names = F)

############# DESeq2 归一化 ############
conds <- c(rep("A",80),rep("B",35))

cds <- estimateSizeFactors( mRNA_dds )
countsNorm <- counts( cds, normalized=TRUE )
countsNorm <- round(countsNorm, digits=1)

limma.input <- round(log2(countsNorm+1),digits = 1)

rownames(limma.input) <- new_exprSet$gene_name

####heatmap热图
#用行名提取数据
#install.packages("pheatmap")

library(pheatmap)
#制作一个分组信息
resAvsB_diff3 <- resAvsB_diff2%>% filter(pvalue <0.05&abs(log2FoldChange)>1)
heatdata <- limma.input[resAvsB_diff3$SYMBOL,]

annotation_col = data.frame(
  Type = factor(conds)
)
rownames(annotation_col) <- colnames(heatdata)
ann_colors <- list(#group=c('Tumor' = "#EFC000FF",'Normal' = '#0073C2FF'),
  Type= c('A' = '#00008B','B' = 'brown3')
) #颜色设置

pheatmap(heatdata)  

pheatmap(heatdata,
         cluster_rows = T,##行聚类
         cluster_cols = T,##列聚类
         annotation_col = annotation_col,###标注样本分类
         annotation_legend = TRUE,
         show_rownames = T,##显示行名
         show_colnames = F,
         scale = "row",
         color = colorRampPalette(c("royalblue","white","firebrick3"))(56),
         annotation_colors = ann_colors
         ##color = colorRampPalette(c("navy", "white", "firebrick3"))(50),
)

dev.off()


##  去除全为零的行
heatdata <- limma.input
heatdata <- heatdata[which(rowSums(heatdata) > 0),]
pheatmap(heatdata, #热图的数据
         cluster_rows = T,#行聚类
         cluster_cols = T,#列聚类，可以看出样本之间的区分度
         annotation_col =annotation_col, #标注样本分类
         annotation_legend=T, # 显示注释
         show_rownames = T,# 显示行名
         show_colnames = T,
         scale = "row", #以行来标准化，这个功能很不错
         color=colorRampPalette(c("navy", "white", "firebrick3"))(100),
         #color=colorRampPalette(c("green","black","red"))(100),
         #color =colorRampPalette(c("blue", "white","red"))(100),#调色
         annotation_colors = ann_colors
)

dev.off()

#volcano火山图
##try drowing a volcano by gglot2
library(ggplot2)
library(ggrepel)
#library(dplyr)
data2 <- resAvsB_all
data2$significant <- as.factor(data2$pvalue <0.05 & abs(data2$log2FoldChange) > 1) ##增加一列significant，设置log2Fold Change>1为yes
table(data2$significant)

data2$change = ifelse(data2$pvalue < 0.05 & abs(data2$log2FoldChange) >= 0.5, 
                        ifelse(data2$log2FoldChange> 0.5 ,'Up','Down'),
                        'No-sig')
p <- ggplot(data=data2, aes(x=log2FoldChange, y =-log10(pvalue),color=change)) +
  geom_point(alpha=0.4, size=1.2)+
  scale_color_manual(values =c('navy','grey','red'))+
  labs(title="Cluster A vs. B", x="log2 (fold change)",y="-log10 (p-value)")+
  theme(plot.title = element_text(hjust = 0.4))+
  geom_hline(yintercept = -log10(0.05),lty=4,lwd=0.6,alpha=0.8)+
  geom_vline(xintercept = c(0.5,-0.5),lty=4,lwd=0.6,alpha=0.8)+
  #theme(legend.position='none')
  theme_bw()+
  theme(panel.border = element_blank(),
        plot.title = element_text(hjust = 0.5,face = 'bold',size = 14),
        axis.text = element_text(size = 10,colour = 'gray30'),
        axis.title = element_text(size = 12,colour = 'black',face = 'bold'),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),   
        axis.line = element_line(colour = "black"))+
  scale_x_continuous(limits = c(-2.5,2.5))+theme(aspect.ratio = 1)
  

p

names(data2)
p+geom_text_repel(data=subset(data2, abs(log2FoldChange) > 1.2), aes(label=SYMBOL),col=c('black'),alpha = 0.8)
##给特定的基因添加名字

ggsave(filename = "3_Volcano_AvsB.pdf",width = 8, height =6,dpi = 300)


####KEGG
#BiocManager::install(clusterProfiler)
library(clusterProfiler)
resAvsB_diff <- resAvsB_all%>% filter(pvalue <0.05&abs(log2FoldChange)>0.5)
gene_up <- resAvsB_diff[resAvsB_diff$log2FoldChange>0,]
gene_down <- resAvsB_diff[resAvsB_diff$log2FoldChange<0,]

kk <- enrichKEGG(gene         = gene_up$ENTREZID,
                 organism     = 'hsa', ##hsa人类 https://www.genome.jp/kegg/catalog/org_list.html
                 pvalueCutoff =0.05,
                 qvalueCutoff = 0.01)

tmp <- data.frame(kk)

BiocManager::install('enrichplot')

library(enrichplot)

barplot(kk, showCategory=10)

barplot(kk, showCategory=10,color = 'pvalue')+ggtitle("KEGG_DEGs_up")

dotplot(kk, showCategory=10,color = 'pvalue') + ggtitle("dotplot for KEGG_DEGs_up")

kk <- setReadable(kk, 'org.Hs.eg.db', 'ENTREZID')
tmp <- data.frame(kk)
write.csv(tmp,"KEGG_DEG_up.csv")

##结果可视化
library(ggplot2)
rownames(tmp) <- 1:nrow(tmp)
tmp$order=factor(rev(as.integer(rownames(tmp))),labels = rev(tmp$Description)) ###对数据均一化

##柱图
ggplot(tmp,aes(y=order,x=Count,fill=pvalue))+
  geom_bar(stat = "identity",width=0.7)+####柱子宽度
  #scale_color_distiller(palette = "Greens")+
  #coord_flip()+##颠倒横纵轴
  #scale_fill_gradient(low = "palegreen4",high ="snow2" )+#颜色自己可以换
  scale_fill_gradient(low = "indianred",high ="navy" )+
  labs(title = "KEGG::Up",
       x = "Gene numbers", 
       y = "Pathways")+
  theme_bw()+
  theme(axis.title.x = element_text(face = "bold",size = 12),
        axis.title.y = element_blank(),
        legend.title = element_text(face = "bold",size = 10),
        plot.title = element_text(size = 14,hjust = 0.5,colour = 'black',face = 'bold',color = 'indianred'),
        axis.text.y = element_text(size = 10,colour = 'black'),
        aspect.ratio =2.4)

ggsave(filename = "3_KEGG_Up.pdf", height = 5, width = 10, dpi = 800)  #TOP20


# GO ----------------------------------------------------------------------
BP ##生物学过程
MF ##分子功能
CC ##细胞定位

ego <- enrichGO(gene          = gene_up$ENTREZID,
                OrgDb         = org.Hs.eg.db,
                ont           = "ALL", ##可以直接选择"ALL"
                pAdjustMethod = "BH",
                pvalueCutoff  = 0.05,
                qvalueCutoff  = 0.05,
                readable      = TRUE)
ego_MF <- enrichGO(gene          = gene_up$ENTREZID,
                   OrgDb         = org.Hs.eg.db,
                   ont           = "MF", ##可以直接选择"ALL"
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.05,
                   qvalueCutoff  = 0.01,
                   readable      = TRUE)
ego_BP <- enrichGO(gene          = gene_up$ENTREZID,
                   OrgDb         = org.Hs.eg.db,
                   ont           = "BP",
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.05,
                   qvalueCutoff  = 0.01,
                   readable      = TRUE)
ego_CC <- enrichGO(gene          = gene_up$ENTREZID,
                   OrgDb         = org.Hs.eg.db,
                   ont           = "CC",
                   pAdjustMethod = "BH",
                   pvalueCutoff  = 0.05,
                   qvalueCutoff  = 0.01,
                   readable      = TRUE)
write.csv(ego_BP,file = "AvsB_go_result_BP_Up.csv",row.names = T)
write.csv(ego_CC,file = "AvsB_go_result_CC_Up.csv",row.names = T)
write.csv(ego_MF,file = "AvsB_go_result_MF_Up.csv",row.names = T)
display_number = c(10,10,10)#这三个数字分别代表选取的BP、CC、MF的通路条数，这个自己设置就行了
ego_result_BP <- as.data.frame(ego_BP)[1:display_number[1], ]
ego_result_CC <- as.data.frame(ego_CC)[1:display_number[2], ]
ego_result_MF <- as.data.frame(ego_MF)[1:display_number[3], ]

go_enrich_df <- data.frame(     #####构建新的数据框
  ID=c(ego_result_BP$ID, 
       ego_result_CC$ID, 
       ego_result_MF$ID),                         
  Description=c(ego_result_BP$Description,
                ego_result_CC$Description,
                ego_result_MF$Description),
  GeneNumber=c(ego_result_BP$Count, 
               ego_result_CC$Count, 
               ego_result_MF$Count),
  type=factor(c(rep("biological process", display_number[1]), 
                rep("cellular component", display_number[2]),
                rep("molecular function", display_number[3])), 
              levels=c("biological process", 
                       "cellular component",
                       "molecular function" )))

for(i in 1:nrow(go_enrich_df)){
  description_splite=strsplit(go_enrich_df$Description[i],split = " ")
  description_collapse=paste(description_splite[[1]][1:5],collapse = " ") #这里的5就是指5个单词的意思，可以自己更改
  go_enrich_df$Description[i]=description_collapse
  go_enrich_df$Description=gsub(pattern = "NA","",go_enrich_df$Description)
}

go_enrich_df$type_order=factor(rev(as.integer(rownames(go_enrich_df))),labels=rev(go_enrich_df$Description))#这一步是必须的，为了让柱子按顺序显示，不至于很乱
COLS <- c("#66C3A5", 
          "#8DA1CB", 
          "#FD8D62")#设定颜色
ggplot(data=go_enrich_df, aes(x=type_order,y=GeneNumber, fill=type)) + #横纵轴取值
  geom_bar(stat="identity", width=0.8) + #柱状图的宽度，可以自己设置
  scale_fill_manual(values = COLS) + ###颜色
  coord_flip() + ##这一步是让柱状图横过来，不加的话柱状图是竖着的
  xlab("GO term") + 
  ylab("Gene_Number") + 
  labs(title = "Enriched GO Terms:Down")+
  theme_bw()+
  theme(aspect.ratio = 2.5,
        plot.title = element_text(size = 11,face = 'bold',vjust = 0.5))
ggsave(filename = "3_DEG_UP_GO_boxplot.pdf", width= 7, height=8, dpi = 800)
ggsave(filename = "3_DEG_Down_GO_boxplot.pdf", width= 7, height=5, dpi = 800)


# GSEA --------------------------------------------------------------------

##构建GSEA分析的数据框
geneList<- resAvsB_all$log2FoldChange #第二列可以是folodchange，也可以是logFC
names(geneList)= resAvsB_all$ENTREZID#用ENTREZID ID富集
geneList=sort(geneList,decreasing = T) #从高到低排序

kk2 <- gseKEGG(geneList     = geneList,
               organism     = 'hsa',
               nPerm        = 1000,
               minGSSize    = 120,
               pvalueCutoff = 1,
               verbose      = FALSE)
head(kk2)

kk2 <- setReadable(kk2, 'org.Hs.eg.db', 'ENTREZID') ##转化表格中的Entrezid ID
tmp <- data.frame(kk2)
tmp <- tmp[tmp$pvalue<0.05,]
write.csv(tmp,file = "3_GSEA_AvsB.csv",col.names = T,row.names = F)


library(enrichplot)
gseaplot2(kk2,geneSetID = 'hsa04145',color="red",pvalue_table = T) 

gseaplot2(kk2, geneSetID = 1:3)

gseaplot2(kk2, geneSetID = c('hsa04062','hsa04060'), pvalue_table = TRUE,
          color = c("#E495A5", #"#86B875", 
                    "#7DB0DD"), ES_geom = "dot")
dotplot(kk2,showCategory=12,split=".sign")+facet_grid(~.sign)
ggsave(filename = "3_GSEA_Dotplot.pdf", width= 9, height=7, dpi = 800)
ggsave(filename = "3_GSEA_CC.pdf", width= 6, height=5, dpi = 800)
