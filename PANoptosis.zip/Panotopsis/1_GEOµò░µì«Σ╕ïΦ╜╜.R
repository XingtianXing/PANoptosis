rm(list = ls()) 
options()$repos #翻墙
options("repos" = c(CRAN="https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
options()$BioC_mirror
options(BioC_mirror="https://mirrors.ustc.edu.cn/bioc/")
options("repos" = c(CRAN="https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))

library(GEOquery)
library(Biobase)
gset <- getGEO('GSE89749', destdir=".",
               AnnotGPL = T,     ## 注释文件
               getGPL = T)       ## 平台文件
gset.8947 <- getGEO('GSE89747', destdir=".",
               AnnotGPL = T,     ## 注释文件
               getGPL = T)       ## 平台文件


show(gset)
expr.GEO <- exprs(gset[[1]])
phe.GEO.8947 <- pData(phenoData(gset.8947[[1]]))
write.csv(phe.GEO,'GSE89749_clinical.csv',row.names = T)
#phe=pData(gset[[1]])

gset #查看测序平台，下载对应的芯片数据
BiocManager::install("illuminaHumanv4.db") ## 查询到测序平台后，获悉所需下载的R软件包进行下载,参考网站http://www.bio-info-trainee.com/1399.html
library(illuminaHumanv4.db) ## 加载基因芯片R软件包
ids=toTable(illuminaHumanv4SYMBOL) ##  获取探针与基因symbol的对应关系
ids[ids$symbol=='TRAF4',] ##  测试：查询“TRAF4”基因所对应的探针

##  对表达矩阵exprSet进行整理及排序
length(unique(ids$symbol))  ###  查看基因symbol独一无二的行有多少
table(sort(table(ids$symbol)))  ### 查看每个基因symbol对应的探针数情况（第一行为探针，第二行为基因symbol统计数）
plot(table(sort(table(ids$symbol))))  ### 用图展示上述对应情况
table(rownames(expr.2) %in% ids$probe_id)  ## 查看表达矩阵exprSet中有多少基因ID在ids中
dim(expr.2)  ### 查看表达矩阵exprSet中的列行数
expr.2=expr.2[rownames(expr.2) %in% ids$probe_id,]  ### 清除表达矩阵exprSet不在ids中的基因ID，从而进行exprSet的重新定义
dim(expr.2)  ### 再次查看表达矩阵exprSet中的列行数，与之前作对比
ids=ids[match(rownames(expr.2),ids$probe_id),]  ### 将ids中的基因ID按照表达矩阵exprSet的顺序进行排列
head(ids)
expr.2[1:5,1:5]  ### 大致查看ids和表达矩阵exprSet的基因ID顺序是否一致

##  构建jimmy函数，对基因ID进行清洗和对基因symbol的匹配，得到新的表达矩阵new_exprSet
jimmy <- function(expr.2,ids){
  tmp = by(expr.2,
           ids$symbol,
           function(x) rownames(x)[which.max(rowMeans(x))] )  ### 一个基因symbol对应的多个探针数时，以其平均表达量的最大值的“列名”对其余探针进行重命名
  probes = as.character(tmp)
  print(dim(expr.2))
  expr.2=expr.2[rownames(expr.2) %in% probes ,]  ### 对重名的基因ID（探针名）进行清除，得到一对一（基因ID与symbol）的对应关系
  print(dim(expr.2))  ### 查看最终基因ID的数量
  rownames(expr.2)=ids[match(rownames(expr.2),ids$probe_id),2]  ### 将ids中的基因symbol匹配到exprSet表达矩阵中
  return(expr.2)} 
new_exprSet_expr.2 <- jimmy(expr.2,ids)
#colnames(new_exprSet)=paste0(group_list,'_',1:47)  ### 为新的表达矩阵new_exprSet按照分组重命名列名
write.csv(new_exprSet,"GSE89749_exprSet.csv")  ### 得到以基因symbol命名的新的表达矩阵new_exprSet,并将其存储为csv格式
save(new_exprSet_expr.1,new_exprSet_expr.2,phe,file='GSE89749.Rdata')

expr.1 <- read.table('GSE89749/GSE89747_Sample_Matrix.txt',row.names = 1,sep = '\t')
expr.2 <- read.table('GSE89749/GSE89748_Sample_Matrix.txt',row.names = 1,sep = '\t',header = T)

expr.1 <- expr.1[,-(colnames(expr.1) == )]
expr.1[,grep("^[Detection.Pval]", names(expr.1), value=TRUE)]
vec <- grep("^[Detection.Pval]", names(expr.1), value=TRUE)
library(dplyr)
expr.1 <- expr.1 %>% select(!vec)

vec <- grep("^[Detection.Pval]", names(expr.2), value=TRUE)
expr.2 <- expr.2 %>% select(!vec)

phe <- read.csv('GSE89749/GSE89749.phe.csv',header = T,check.names = F,row.names = 1)
phe <- na.omit(phe)

new_exprSet_expr.1=new_exprSet_expr.1[rownames(new_exprSet_expr.1) %in% rownames(new_exprSet_expr.2),]
new_exprSet_expr.1[1:5,1:5]
new_exprSet_expr.2[1:5,1:5]
new_exprSet_expr.2=new_exprSet_expr.2[match(rownames(new_exprSet_expr.1),rownames(new_exprSet_expr.2)),]
new_exprSet <- cbind(new_exprSet_expr.1,new_exprSet_expr.2)
save(new_exprSet_expr.1,new_exprSet_expr.2,phe,new_exprSet,file='GSE89749.Rdata')

new_exprSet <- new_exprSet[,match(rownames(phe),colnames(new_exprSet))]

PRG <- read.csv('./PRGs.list.csv',header = F)
expr_PRG <- new_exprSet[rownames(new_exprSet)%in%PRG$V1,]

library(RColorBrewer)
library(pheatmap)
library(ggplot2)
library(ggpubr)
col = colorRampPalette(brewer.pal(11,'RdGy'))(100)
col = rev(col)

clu2$sample <- rownames(clu2)
clu2 <- clu2[order(clu2$cluster2),]
vec <- as.vector(rownames(clu2))
phe_clu2 <- phe %>%
  arrange_at(1:21) %>%
  arrange(match(rownames(phe),vec)) #按cluster2的序列排序
colnames(phe_clu2)
phe_clu2 <- phe_clu2[,c(3,4,5,9,11,12,13,22)]
names(phe_clu2) <- c("Sex","Age","Anatomical",'Histology',             
                    "Stage","Status","OS","cluster2")
expr_PRG_clu2 <-  expr_PRG[,match(vec,colnames(expr_PRG))]

table(phe_clu2$cluster2)
anno_colors <- list(Sex= c('M' = 'navy','F' = '#CD534CFF'),
                   cluster2= c('1' = 'darkcyan','2' = 'darkmagenta'),
                   Stage=c('0' = '#7FC97F',
          'I' = '#BEAED4',
          'IA' = '#FDC086',
          'II' ='#F0027F',
          'IIA' = '#FFFF99',
          'IIB' = '#386CB0',
          'III' = '#E41A1C',
          'IIIA'= '#377EB8',
          'IIIB' = '#4DAF4A',
          'IV' = '#984EA3',
          'IVA' = '#FF7F00',
          'IVB' = '#FFFF33'),
          Status=c('0'='#FFB90F','1'='black'),
          Anatomical=c('Distal'='#7FC97F','Extrahepatic'='#BEAED4',
                       'Intrahepatic'='#FDC086','Perihilar'='#FFFF99')
 # Histology=c('Adenosquamous carcinoma'='#386CB0','Moderate'='#F0027F','Moderate-Poor'='#BF5B17',
 #             'Papillary carcinoma'="#666666",),
  #age=c('1'='deeppink3','0'='deepskyblue4')
) #颜色设置a

pheatmap(expr_PRG_clu2,cluster_rows = T,cluster_cols = F,
         color = col,
         show_colnames = F ,Fborder_color = NA,scale = "row",show_rownames =T,
         annotation_col = phe_clu2,
         name = 'Expression',
         cellwidth = 1.5,cellheight = 10,
         fontsize_row = 8,
         annotation_colors = ann_colors,
         legend_breaks = 2
)

phe_clu3$cluster <- clu3$cluster3
clu3$sample <- rownames(clu3)
clu3 <- clu3[order(clu3$cluster3),]
vec <- as.vector(rownames(clu3))
colnames(phe_clu3)
phe_clu3 <- phe_clu3[,c(3,4,5,11,12,13,23)]
names(phe_clu3) <- c("Sex","Age","Anatomical",          
                     "Stage","Status","OS","cluster")
expr_PRG_clu3 <-  expr_PRG[,match(vec,colnames(expr_PRG))]

table(phe_clu3$cluster)
anno_colors <- list(Sex= c('M' = 'navy','F' = '#CD534CFF'),
                  cluster= c('1' = '#EE7600','2' = '#008B8B','3'='brown3'),
                  Stage=c('0' = '#7FC97F',
                          'I' = '#BEAED4',
                          'IA' = '#FDC086',
                          'II' ='#F0027F',
                          'IIA' = '#FFFF99',
                          'IIB' = '#386CB0',
                          'III' = '#E41A1C',
                          'IIIA'= '#377EB8',
                          'IIIB' = '#4DAF4A',
                          'IV' = '#984EA3',
                          'IVA' = '#FF7F00',
                          'IVB' = '#FFFF33'),
                  Status=c('0'='#FFB90F','1'='black'),
                  Anatomical=c('Distal'='#7FC97F','Extrahepatic'='#BEAED4',
                               'Intrahepatic'='#FDC086','Perihilar'='#FFFF99')
                  # Histology=c('Adenosquamous carcinoma'='#386CB0','Moderate'='#F0027F','Moderate-Poor'='#BF5B17',
                  #             'Papillary carcinoma'="#666666",),
                  #age=c('1'='deeppink3','0'='deepskyblue4')
) #颜色设置

pheatmap(expr_PRG_clu3,cluster_rows = T,cluster_cols = F,
         color = col,
         show_colnames = F ,Fborder_color = NA,scale = "row",show_rownames =T,
         annotation_col = phe_clu3,
         name = 'Expression',
         cellwidth = 1.5,cellheight = 10,
         fontsize_row = 8,
         annotation_colors = anno_colors,
         legend_breaks = 2
)

rownames(clu3)[1:10]
rownames(phe)[1:10]
phe$cluster2 <- clu2$`results[[2]][["consensusClass"]]`
phe$cluster3 <- clu3$cluster3
KM=phe
colnames(KM)
KM <- KM[,c(2,3,4,5,6,7,8,10,11,12,13,22,23)]
names(KM)[10] <- 'State'
names(KM)[11] <- 'OS'
library(survminer)
library(survival)
library(survMisc)
fit <- survfit(Surv(OS, State)~newclus, data = KM)
ggsurvplot(fit,
           pval = TRUE, conf.int = TRUE,
           risk.table = TRUE, # 添加风险表
           risk.table.col = "strata", # 根据分层更改风险表颜色
           linetype = "strata", # 根据分层更改线型
           surv.median.line = "hv", # 同时显示垂直和水平参考线
           #ggtheme = theme(aspect.ratio = 0.6), # 更改ggplot2的主题
           palette = c(#"#EE7600", "#008B8B",
                       '#00008B',
                       'brown3'
                       ))

library(do)
clu3$newclus <- Replace(data = clu3$newclus, from = c('1','2'),to = c("A"))
clu3$newclus <- Replace(data = clu3$newclus, from = c('3'),to = c("B"))
KM$newclus <- clu3$newclus

expr_PRG <- new_exprSet[rownames(new_exprSet)%in%PRG$V1,]
Gse.se <- CreateSeuratObject(counts = expr_PRG, project = "CHOL", min.cells = 0)
colnames(Gse.se)[1:10]
phe <- phe[match(colnames(Gse.se),rownames(phe)),]
rownames(phe)[1:10]
Gse.se$cluster <- phe$cluster
Gse.se$cluster2 <- phe$cluster2
Gse.se$cluster3 <- phe$cluster3

Gse.se<-SCTransform(Gse.se)
Gse.se <- FindVariableFeatures(Gse.se,selection.method = "vst", nfeatures =  2000)
Gse.se <- RunPCA(Gse.se, npcs=3, verbose=FALSE)
Gse.se<- RunUMAP(Gse.se, dims = 1:3)
cluster.col <- c('#00008B','brown3')
cluster2.col <- c("#EE7600", "#008B8B")
cluster3.col <- c("#EE7600", "#008B8B",'brown3')

DimPlot(Gse.se,reduction = "umap",group.by = "cluster3", pt.size =2, label = F,repel = T,cols = cluster3.col)+ 
  #scale_color_d3('category20')+
  labs(x = "PCA_1", y = "PCA_2", title = "PCA")+
  theme(panel.border = element_rect(fill = NA,color = "black",size = 0.8,linetype = "solid"),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        plot.title = element_text(hjust = 0.5))+theme(aspect.ratio = 1)
ggsave(filename = '2_PCA_Cluster3.pdf',width = 4,height = 4,dpi = 800)

#install.packages("ggthemes")
library(ggpubr)
library(ggthemes)
#BiocManager::install("gmodels")
library(gmodels)
library(export)

#用gmodels里面自带的fast.prcomp对PC进行计算。
##这里的矩阵行是基因名，列是样本名
fpkm <- expr_PRG
pca.info <- fast.prcomp(fpkm) ###矩阵只有数值没有字符,数据不用转置
#查看PCA的结果。
head(pca.info)
summary(pca.info) #能看到每个PC具体的解释比例
head(pca.info$rotation) #特征向量，回归系数
head(pca.info$sdev) #特征值的开方
head(pca.info$x) #样本得分score
type <- clu2[match(rownames(pca.info$rotation),rownames(clu2)),]
type.info <- as.vector(type$cluster2)
type.info <- as.character(type.info)

pca.data <- data.frame(sample = rownames(pca.info$rotation), 
                       Type=c(type.info), pca.info$rotation)
#绘图，不同的参数会有不同的结果。具体的参数以及含义自行百度。以下是两个例子。

ggscatter(pca.data,x="PC1", y="PC2", color="Type",ellipse=F, 
          #ellipse.type="convex",
          size=2, 
          ellipse.border.remove=TRUE,
          label.select = pca.data$sample,
          label = TRUE,
          repel=TRUE, main="PCA plot")+ 
  labs(title = "PCA",
       x = "PC_1", 
       y = "PC_2")+
  theme(axis.title.x = element_text(face = "bold",size = 20),
        axis.title.y = element_text(face = "bold",size = 20),
        legend.title = element_text(face = "bold",size = 16))+
  theme_par()+theme(aspect.ratio = 1)+
  scale_color_manual(values = cluster2.col)
ggsave(filename = '2_PCA_Cluster2_real.pdf',width = 6,height = 6,dpi = 800)

