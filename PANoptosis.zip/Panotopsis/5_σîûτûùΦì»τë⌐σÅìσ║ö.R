all(rownames(predictedPtype_solid)==rownames(riskScore_cli))
predictedPtype_solid <- predictedPtype_solid[match(rownames(riskScore_cli),rownames(predictedPtype_solid)),]
predictedPtype_solid$RiskScore <- riskScore_cli$riskScore3
library(ggplot2)

colnames(predictedPtype_solid)
my_comparisons <- list(c('Low','High'))
ggplot(predictedPtype_solid,aes(x=factor(RiskScore,levels = c('Low','High')),y=Bexarotene))+ 
  geom_violin(aes(fill=RiskScore),cex=1.2)+           
  geom_boxplot(width=0.08,cex=1.2)+      #设置箱线图宽度     
  theme_classic(base_size = 20)+        #可设置不同的主题
  theme(axis.text = element_text(color = 'black'), #默认坐标轴刻度颜色其实是灰色，这里我们修改成黑色
        legend.position = 'none',
        plot.title = element_text(size = 16,face = 'bold',hjust = 0.5),
        aspect.ratio = 1) +      #去掉图例
  labs(title = 'Bexarotene',y='',x='')+
  stat_compare_means(comparisons = my_comparisons)
ggsave('6_Bexarotene.pdf',width = 4,height = 5,dpi = 800)
