Immucell <- read.table('ImmuCellAI_abundance_result.txt',sep = '\t',header = T)
names(Immucell)[1] <- 'sample'
rownames(Immucell)[1:10]
rownames(clu3)[1:10]
Immucell$cluster <- clu3$newclus
library(reshape2)
Immucell <- melt(Immucell,id =c('sample','cluster'),variable.name = 'Celltype',value.name = 'Abundance')
celltype <- c("DC" ,"B_cell","Monocyte","Macrophage","NK",               
             "Neutrophil","CD4_T","CD8_T","NKT","Gamma_delta")
Immucell <- Immucell[Immucell$Celltype%in%celltype,]
ggplot(Immucell,aes(x=cluster,y=InfiltrationScore,fill=cluster,color=cluster))+
  #geom_violin(position = position_dodge(width = 0.8),scale = 'area')+
  geom_boxplot()+
  scale_fill_manual(values = c('A'='white','B'='white'))+
  scale_color_manual(values = c('A' = "#00008B",'B' = "brown3"))+
  theme_bw()+
  theme(panel.grid = element_line(color = 'white'))+
  ylab('Infiltration Score')+xlab('')+
  labs(title = 'Immune Cells Inflitration')+
  #geom_dotplot(binaxis = 'y',stackdir = 'center',dotsize = 0.2,binwidth = 0)+
  #geom_jitter(shape=16,position = position_jitter(0))+
  theme(plot.title = element_text(hjust = 0.5,size = 14,face = 'bold'),
        axis.title.y = element_text(hjust = 0.5,size = 10,face = 'bold'),
        axis.text.x = element_text(hjust = 0.5,size = 12,face = 'italic'))+
  RotatedAxis()+stat_compare_means(aes(group = cluster),label = 'p.format',label.y =0.89,label.x = 1.8)+
  theme(aspect.ratio = 0.85)
ggsave('2_ImmuneInflitration_Score.pdf',width = 4,height = 4,dpi = 800)

celltype <- c("DC" ,"B_cell","Monocyte","Macrophage","NK",               
              "Neutrophil","CD4_T","CD8_T","NKT","Gamma_delta")
celltype <- c("CD4_naive","Tr1","nTreg","iTreg","Th1",            
              "Th2","Th17","Tfh","CD8_naive","Cytotoxic",      
              "Exhausted","MAIT","Central_memory","Effector_memory")
Immucell_10 <- Immucell[Immucell$Celltype%in%celltype,]
compare_means(Abundance ~ cluster ,data = Immucell)
p <- ggboxplot(Immucell_10, x = "cluster", y = "Abundance",
               color = "cluster",
               add = "jitter",xlab = NULL,
               facet.by = "Celltype", short.panel.labs = FALSE)+
  scale_fill_manual(values = c('A'='white','B'='white'))+
  scale_color_manual(values = c('A' = "#00008B",'B' = "brown3"))+
  labs(x='',y='')
#p+ stat_compare_means(aes(group = cluster),label = 'p.signif',label.y =2)
p+   stat_compare_means(aes(group = cluster),label = 'p.format',label.y =0.025,label.x = 1.8)+
  theme(aspect.ratio = 0.85)
ggsave('2_ImmuneInflitration_20celltypes.pdf',width = 9,height = 9,dpi = 800)
