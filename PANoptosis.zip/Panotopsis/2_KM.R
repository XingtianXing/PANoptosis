clinical_matrix_Tumor <- read.csv('clinical_tumor_pick.csv',row.names = 1)
KM=clinical_matrix_Tumor
colnames(KM)
tumor_matrix_PRGs <- t(tumor_matrix_PRGs)
tumor_matrix_PRGs <- as.data.frame(tumor_matrix_PRGs)
tumor_matrix_PRGs$gene <- rownames(tumor_matrix_PRGs)
vec <- rownames(clinical_matrix_Tumor)
tumor_matrix_PRGs <- tumor_matrix_PRGs%>%
  arrange_at(1:19)%>%
  arrange(match(gene,vec))
vec[1:4]
rownames(tumor_matrix_PRGs)[1:4]
rownames(clinical_matrix_Tumor)[1:4]

for (i in 1:19) {
  a <- as.data.frame(expr[,i]) 
  rownames(a) <- rownames(expr)
  names(a)[1] <- 'count'
  
  b <- as.data.frame(rep('Low',118))
  a$Expression <- b$`rep("Low", 118)`
  a$Expression[a$count > median(a$count)] <- 'High'
  KM$Gene <- a$Expression
  
  fit <- survfit(Surv(OS, State)~Gene, data = KM)
p[i] <-   ggsurvplot(fit,
             pval = TRUE, conf.int = TRUE,
             risk.table = TRUE, # 添加风险表
             risk.table.col = "strata", # 根据分层更改风险表颜色
             linetype = "strata", # 根据分层更改线型
             surv.median.line = "hv", # 同时显示垂直和水平参考线
             ggtheme = theme_bw(), # 更改ggplot2的主题
             palette = c("#E7B800", "#2E9FDF"))+#定义颜色
  labs(title = paste0(colnames(expr)[i],'- Survival'))
}

library(cowplot)
plot_grid(p[[1]],
          p[[2]],
          p[[3]],
          p[[4]],
          p[[5]],
          p[[6]],
          p[[7]],
          p[[8]],
          p[[9]],ncol = 3)

plot_grid(p[[11]],
          p[[12]],
          p[[13]],
          p[[14]],
          p[[15]],
          p[[16]],
          p[[17]],
          p[[18]],
          p[[19]],ncol = 3)

a <- as.data.frame(tumor_matrix_PRGs$ZBP1) 
rownames(a) <- rownames(tumor_matrix_PRGs)
names(a)[1] <- 'count'

b <- as.data.frame(rep('Low',32))
a$Expression <- b$`rep("Low", 32)`

a$Expression[a$count > median(a$count)] <- 'High'

KM$ZBP1 <- a$Expression
rownames(KM)[1:3]
rownames(a)[1:3]

#library(ggplot2)
#library(survminer)
#library(survival)
#BiocManager::install('survminer')
#library(survminer)
fit <- survfit(Surv(os, Status)~ZBP1, data = KM)
ggsurvplot(fit,
           pval = TRUE, conf.int = TRUE,
           risk.table = TRUE, # 添加风险表
           risk.table.col = "strata", # 根据分层更改风险表颜色
           linetype = "strata", # 根据分层更改线型
           surv.median.line = "hv", # 同时显示垂直和水平参考线
           ggtheme = theme_bw(), # 更改ggplot2的主题
           palette = c("#E7B800", "#2E9FDF"))#定义颜色

