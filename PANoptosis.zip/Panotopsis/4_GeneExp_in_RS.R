fpkm <- read.csv('Figure2_Data/fpkm_newExprt_GEO_SYMBOL.csv',row.names = 1,check.names = F)
fpkm.PRG <- fpkm[rownames(fpkm)%in%PGR$V1,]
expr_PRG2 <- fpkm.PRG[,-which(colnames(fpkm.PRG) %in% sample)]
expr_PRG2 <- t(expr_PRG2)
expr_PRG2 <- expr_PRG2[match(rownames(riskScore_cli),rownames(expr_PRG2)),]
all(rownames(riskScore_cli)==rownames(expr_PRG2))
expr_PRG2 <- as.data.frame(expr_PRG2)
expr_PRG2$sample <- rownames(expr_PRG2)
expr_PRG2$risk2 <- riskScore_cli$riskScore2
expr_PRG2$risk3 <- riskScore_cli$riskScore3
expr_PRG2$cluster <- riskScore_cli$Cluster


library(plyr)
library(ggpubr)
library(ggsci)
library(Seurat)

expr_PRG2_melt <- reshape2::melt(expr_PRG2,id =c('sample','cluster','risk2','risk3'),variable.name = 'gene',value.name = 'expression')
expr_PRG2_melt <- as.data.frame(expr_PRG2_melt)
expr_PRG2_melt$expression <- as.numeric(expr_PRG2_melt$expression)
class(expr_PRG2_melt$expression)

expr_PRG2_melt$expression[expr_PRG2_melt$expression>50] = 50

ggplot(expr_PRG2_melt[expr_PRG2_melt$gene == 'PARP1',],aes(x=risk3,y=expression,fill=risk3,color=risk3))+
  #geom_violin(position = position_dodge(width = 0.8),scale = 'area')+
  geom_boxplot()

ggplot(expr_PRG2_melt,aes(x=gene,y=expression,fill=risk3,color=risk3))+
  #geom_violin(position = position_dodge(width = 0.8),scale = 'area')+
  geom_boxplot()+
  scale_fill_manual(values = c('Low' = 'white','High' = 'white'))+
  scale_color_manual(values = c('Low' = '#00008B','High' = 'brown3'))+
  #scale_color_jco()+
  theme_bw()+
  theme(panel.grid = element_line(color = 'white'))+
  ylab('Gene expression/ FPKM')+xlab('')+
  labs(title = 'Panoptosis-Related Genes Expession')+
  #geom_dotplot(binaxis = 'y',stackdir = 'center',dotsize = 0.2,binwidth = 0)+
  #geom_jitter(shape=16,position = position_jitter(0))+
  theme(plot.title = element_text(hjust = 0.5,size = 14,face = 'bold'),
        axis.title.y = element_text(hjust = 0.5,size = 12,face = 'bold'),
        axis.text.x = element_text(hjust = 0.5,size = 11,face = 'italic'))+
  theme(aspect.ratio = 0.6)+
  RotatedAxis()
ggsave(filename = '2_PRG_Expression_Boxplot_FPKM.pdf',width = 8,height = 6,dpi = 800)
ggsave(filename = '4_PRG_Expression_Boxplot_FPKM_Risksta.pdf',width = 8,height = 6,dpi = 800)

p <- ggboxplot(expr_PRG2_melt, x = "risk3", y = "expression",
               color = "risk3",
               add = "jitter",xlab = NULL,
               facet.by = "gene", short.panel.labs = FALSE)+
  scale_color_manual(values = c('#00008B','brown3'))
p+ stat_compare_means(aes(group = risk3),label = 'p.signif',label.y = 45)
p+   stat_compare_means(aes(group = risk2),label = 'p.format',label.y = 45,label.x = 1.8)
ggsave(filename = '2_PRG_Boxplot_FPKM_P.pdf',width = 10,height = 9,dpi = 800)
ggsave(filename = '4_PRG_Boxplot_FPKM_P_Median.pdf',width = 10,height = 9,dpi = 800)
