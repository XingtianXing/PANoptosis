library(dplyr)
phe115 <- phe[rownames(phe) %in% rownames(KM.1),]
phe115 <- phe115[match(rownames(riskScore_cli),rownames(phe115)),]
all(rownames(riskScore_cli)==rownames(phe115))
colnames(phe115)
colnames(riskScore_cli)
write.csv(phe115,file = 'clinical_115_full.csv',row.names = T)
write.csv(riskScore_cli,file = 'clinical_115.csv',row.names = T)
write.csv(new_exprSet2,file = 'exprSet_115.csv',row.names = T)

colnames(immuecell)
DC <- as.data.frame(immuecell$DC)
rownames(DC) <- rownames(immuecell)
names(DC) <- 'DC'
DC$risk <- immuecell$risk
DC$risk2 <-  immuecell$risk2
DC$risk3 <-  immuecell$risk3
DC$abundance <- log2(immuecell$DC)

s.cell <- c("DC","B_cell","Monocyte","Macrophage","NK",               
            "Neutrophil","CD4_T","CD8_T","NKT","Gamma_delta")

library(ggpubr)
library(dplyr)

colnames(immuecell)
    
for (i in 11:24) {
  p <-     ggscatter(immuecell, x = "RiskScore", y = names(immuecell)[i], 
                     color = "red3",fill = "lightgray",
                     add = "reg.line", conf.int = TRUE, 
                     add.params = list( color = "black",fill = "lightgray",fill = "lightgray"),
                     cor.coef = T,
                     cor.coeff.args = list(),
                     cor.method = "pearson",
                     cor.coef.coord = c(13,0.01),
                     cor.coef.size = 4)+
    labs(y = paste0('Abundance of ',names(immuecell)[i]))+
    theme(aspect.ratio = 1,axis.title = element_text(size = 12,face = 'bold'))
  ggsave(p,filename = paste0('5_',i,'_',names(immuecell)[i],'_RiskScore_linear_pearson.pdf'),width = 4,height = 4,dpi = 800)
}

immuecell$InfiltrationScore_Log2 <- log2(immuecell$InfiltrationScore)
immuecell.s <- immuecell[immuecell$risk2=='High',]
p <-     ggscatter(immuecell.s, x = "RiskScore", y = 'InfiltrationScore', 
                   #color = "navy",
                   color = "brown3",
                   fill = "lightgray",
                   add = "reg.line", conf.int = TRUE, 
                   add.params = list( color = "black",fill = "lightgray",fill = "lightgray"),
                   cor.coef = T,
                   cor.coeff.args = list(),
                   cor.method = "pearson",
                   cor.coef.coord = c(8,0.92),
                   cor.coef.size = 5)+
  labs(y = paste0('Infiltration Score'),x='High RiskScore - cutoff:Median')+
  theme(aspect.ratio = 1,axis.title = element_text(size = 12,face = 'bold'))
p
ggsave(p,filename = '5_ImmueScore_High_Median.pdf',width = 4,height = 4,dpi = 800)
ggsave(p,filename = paste0('5_',i,'_',names(immuecell)[i],'_RiskScore_linear_pearson.pdf'),width = 4,height = 4,dpi = 800)
