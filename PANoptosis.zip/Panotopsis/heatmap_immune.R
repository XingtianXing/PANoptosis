colnames(immuecell)
riskgroup <- as.data.frame(phe_gai$riskScore3)
rownames(riskgroup) <- rownames(phe_gai)
names(riskgroup) <- 'riskscore'
riskgroup$sample <- rownames(riskgroup)
riskgroup <- riskgroup[order(riskgroup$riskscore,decreasing = T),]
immuecell <- immuecell[match(rownames(riskgroup),rownames(immuecell)),]
all(rownames(riskgroup) == rownames(immuecell))
library(pheatmap)

immucell_for_heatmap <- t(immuecell)
immucell_for_heatmap <- as.data.frame(immucell_for_heatmap)
rownames(immucell_for_heatmap)
immucell_for_heatmap <- immucell_for_heatmap[1:25,]

colnames(phe_gai_1) 
riskgroup <- phe_gai_1[,c(1,4,9,13)]
ann_colors <- list(riskScore3=c('Low'='navy','High'='brown3'),
                   Sex=c('M' = 'green','F' = '#CD534CFF'),
                   age=c('1'='deeppink3','0'='deepskyblue4'),
                   HBV=c('Negative'='gold','Positive'='orchid4'))
p <- pheatmap(immuecell[,11:24],
         cluster_rows = T,cluster_cols = T,
         #color=colorRampPalette(c("navy","white","firebrick3"))(100),
         #color = col,
         show_colnames = T,border_color = NA,scale = "row",show_rownames =F,
         annotation_row  = riskgroup,
         name = 'Expression',
         cellwidth = 10,cellheight = 1.5,
         fontsize_row = 9,
         annotation_colors = ann_colors
         #legend_breaks = 2
)

