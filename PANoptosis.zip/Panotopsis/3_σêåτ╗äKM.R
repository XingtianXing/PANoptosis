#KM分析
colnames(phe_gai_1) 
table(phe_gai_1$HBV)
phe_gai_1$anatomical <- phe_gai_1$Anatomical
phe_gai_1$anatomical[phe_gai_1$anatomical %in% c('Distal', 'Extrahepatic','Perihilar')] = 'Others'
fit <- survfit(Surv(OS, State) ~ riskScore3, data=phe_gai_1[phe_gai_1$HBV=='Positive',])
p <- ggsurvplot(fit,
                      pval = TRUE, conf.int = TRUE,
                      risk.table = TRUE, # 添加风险表
                      risk.table.col = "strata", # 根据分层更改风险表颜色
                      linetype = "strata", # 根据分层更改线型
                      surv.median.line = "hv", # 同时显示垂直和水平参考线
                      #ggtheme = theme(aspect.ratio = 0.6), # 更改ggplot2的主题
                      palette = c(#"#EE7600", "#008B8B",
                        'brown3','#00008B'),
           ggtheme = theme_bw(),
                        legend.labs=c('High','Low'))
p$plot <-  p$plot+ labs(title = 'HBV:Positive')+
  theme(plot.title = element_text(hjust = 0.5,face = 'bold',size = 16))

gg <- print(p)
ggsave(plot=print(p),filename = '4_subgroup_HBVpo_KM.pdf',width = 4,height = 5,dpi = 800)
