library(org.Hs.eg.db)
eg = bitr(rownames(fpkms.m), fromType="ENSEMBL", toType="SYMBOL", OrgDb="org.Hs.eg.db")
fpkms.m$ENSEMBL <- rownames(fpkms.m)
fpkms.m2<-inner_join(eg,fpkms.m,by="ENSEMBL") ###取共有的集合做内连接
fpkms.m2 <- fpkms.m2[!duplicated(fpkms.m2$SYMBOL),]
rownames(fpkms.m2) <- fpkms.m2$SYMBOL
fpkms.m2 <- fpkms.m2[,-1]
write.csv(fpkms.m2,'fpkm_newExprt_GEO_SYMBOL.csv',row.names = T)

fpkms.m2 <- as.data.frame(fpkms.m2)
fpkms.m_PRG <- fpkms.m2[rownames(fpkms.m2)%in%PRG$V1,]
fpkms.m_PRG <- t(fpkms.m_PRG)
fpkms.m_PRG <- fpkms.m_PRG[match(rownames(clu3), rownames(fpkms.m_PRG)),]
rownames(clu3)[1:10]
rownames(fpkms.m_PRG)[1:10]
fpkms.m_PRG <- as.data.frame(fpkms.m_PRG)
fpkms.m_PRG$cluster <- clu3$newclus
fpkms.m_PRG$sample <- rownames(fpkms.m_PRG)
fpkms.m_PRG <- reshape2::melt(fpkms.m_PRG,id =c('sample','cluster'),variable.name = 'gene',value.name = 'expression')

library(plyr)
library(ggpubr)
library(ggsci)
library(Seurat)

fpkms.m_PRG[fpkms.m_PRG$expression>100,] <- 100
fpkms.m_PRG <- na.omit(fpkms.m_PRG)
ggplot(fpkms.m_PRG,aes(x=gene,y=expression,fill=cluster,color=cluster))+
  #geom_violin(position = position_dodge(width = 0.8),scale = 'area')+
  geom_boxplot()+
  scale_fill_manual(values = c('A' = 'white','B' = 'white'))+
  scale_color_manual(values = c('A' = '#00008B','B' = 'brown3'))+
  #scale_color_jco()+
  theme_bw()+
  theme(panel.grid = element_line(color = 'white'))+
  ylab('Gene expression/ FPKM')+xlab('')+
  labs(title = 'Panoptosis-Related Genes Expession')+
  #geom_dotplot(binaxis = 'y',stackdir = 'center',dotsize = 0.2,binwidth = 0)+
  #geom_jitter(shape=16,position = position_jitter(0))+
  theme(plot.title = element_text(hjust = 0.5,size = 14,face = 'bold'),
        axis.title.y = element_text(hjust = 0.5,size = 12,face = 'bold'),
        axis.text.x = element_text(hjust = 0.5,size = 11,face = 'italic'))+
  theme(aspect.ratio = 0.6)+
  RotatedAxis()
ggsave(filename = '2_PRG_Expression_Boxplot_FPKM.pdf',width = 8,height = 6,dpi = 800)

p <- ggboxplot(fpkms.m_PRG, x = "cluster", y = "expression",
               color = "cluster",
               add = "jitter",xlab = NULL,
               facet.by = "gene", short.panel.labs = FALSE)+
  scale_color_manual(values = cluster.col)
p+ stat_compare_means(aes(group = cluster),label = 'p.signif',label.y = 60)
p+   stat_compare_means(aes(group = cluster),label = 'p.format',label.y = 60,label.x = 1.8)
ggsave(filename = '2_PRG_Boxplot_FPKM_P.pdf',width = 10,height = 9,dpi = 800)
