BiocManager::install('maftools')
library(maftools)
library(tidyverse)

#读入GISTIC输出的文件
laml.gistic = readGistic(gisticAllLesionsFile = './CHOL/all_lesions.conf_90.txt',
                         gisticAmpGenesFile = './CHOL/amp_genes.conf_90.txt', 
                         gisticDelGenesFile = './CHOL/del_genes.conf_90.txt', 
                         gisticScoresFile = './CHOL/scores.gistic', 
                         isTCGA = T)
laml.gistic

chol.gistic <- read.maf(gisticAllLesionsFile="all_lesions.conf_99.txt", gisticAmpGenesFile="amp_genes.conf_99.txt", gisticDelGenesFile="del_genes.conf_99.txt", 
                        gisticScoresFile="scores.gistic")
# 因为样本数太多，使用borderCol=NULL不显示样本边界。可惜的是目前gisticOncoPlot还没有加上这个参数
oncoplot(maf=luad.plus.gistic, borderCol=NULL, top=10)

##可视化
##绘图
#genome plot 部分突出了明显的扩增和删失区域
gisticChromPlot(gistic = laml.gistic, ref.build = 'hg38') ## 参考基因组选hg38

#Bubble plot 绘制显著改变的cytobands,以及改变的样本数和它所包含的基因数的函数。每一个气泡的大小是根据-log10转化q值。
gisticBubblePlot(gistic = laml.gistic)

#oncoplot  
gisticOncoPlot(gistic = laml.gistic, 
               sortByAnnotation = TRUE, top =20)

###下载Maf文件
BiocManager::install('TCGAbiolinks')
library(TCGAbiolinks)

query <- GDCquery(
  project = "TCGA-CHOL", 
  data.category = "Simple Nucleotide Variation",
  data.type = "Masked Somatic Mutation",
  access = "open"
)

GDCdownload(query)

GDCprepare(query, save = T,save.filename = "TCGA-CHOL_SNP.Rdata")

library(maftools)

load(file = "./TCGA-CHOL_SNP.Rdata")

maf.coad <- data
maf <- read.maf(maf.coad,clinicalData = 'TCGA/clinical_matrix.csv',isTCGA = T)
## -Validating
## -Silent variants: 63597 
## -Summarizing
## --Mutiple centers found
## BCM;WUGSC;BCM;WUGSC;BCM;BI--Possible FLAGS among top ten genes:
##   TTN
##   SYNE1
##   MUC16
## -Processing clinical data
## --Missing clinical data
## -Finished in 6.000s elapsed (5.690s cpu)

plotmafSummary(maf = chol.plus.gistic, rmOutlier = TRUE, addStat = 'median', dashboard = TRUE)

chol.plus.gistic <- read.maf(maf= maf.coad, gisticAllLesionsFile="CHOL/all_lesions.conf_90.txt",
                             gisticAmpGenesFile="CHOL/amp_genes.conf_90.txt",
                             gisticDelGenesFile="CHOL/del_genes.conf_90.txt",
                             gisticScoresFile="CHOL/scores.gistic",clinicalData = 'TCGA/clinical_matrix.csv',isTCGA = T)
# 因为样本数太多，使用borderCol=NULL不显示样本边界。可惜的是目前gisticOncoPlot还没有加上这个参数
oncoplot(maf=chol.plus.gistic, borderCol=NULL, genes = PRG$gene)
oncoplot(maf =maf, fontSize = 0.45 ,showTumorSampleBarcodes = F ,
         clinicalFeatures = 'gender',titleFontSize=1.2,legendFontSize=0.7,
         removeNonMutated=F,writeMatrix=T,annotationFontSize=0.7,
         genes = PRG)

##选取要展示的基因
PRG <- read.csv('PRGs.list.csv',header = F)
names(PRG) <- 'gene'
PRG <- as.factor(PRG$gene)

display.brewer.all()
variant_colors <- c(brewer.pal(7,'Accent'),brewer.pal(6,'Dark2')[2:7])
#variant_colors <- ggsci::pal_simpsons()(9)
oncoplot(maf =chol.plus.gistic, fontSize = 0.8 ,showTumorSampleBarcodes = F ,
         clinicalFeatures = 'gender',titleFontSize=1.2,legendFontSize=0.7,
         removeNonMutated=F,writeMatrix=T,annotationFontSize=0.8,
         genes = gene,
         selectedPathways = T,
         borderCol = NULL,colors = variant_colors,draw_titv = T)

gene <- c('TAB2','CASP7','NLRP3','IRF1')


